#!/usr/bin/env python
# coding: utf-8

# ### Загрузка данных

# *Загружаем данные и все необходимые библиотеки:*

# In[1]:


import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
import re
import csv
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings('ignore')
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn import decomposition
from sklearn.metrics import silhouette_score
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import RFE
import numpy as np
from lightgbm import LGBMClassifier
from sklearn.feature_selection import RFECV
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn import decomposition
from sklearn.metrics import silhouette_score
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import train_test_split
import nltk 
import re
from nltk.stem import wordnet 
from nltk import pos_tag  
from nltk import word_tokenize 
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer 
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.metrics import pairwise_distances 


# In[2]:


data=pd.read_csv("data.csv")
data.head(3)


# In[3]:


data.shape


# In[4]:


data.describe()


# ### Предобработка данных

# **Обработка пропущенных значений**

# *Для того, что бы мы смогли обучить модель, необходимо избавиться от пропущенных значений.Выведим их колличество на экран в процентах:*

# In[5]:


for col in data.columns:
    missing=np.mean(data[col].isnull())
    print("{}%-{}".format(col, round(missing*100)))
    if missing > 0.90:
        del data[col]


# *Заменяем пропущенные значения, предыдущими значениями.*

# In[6]:


data.ffill(axis = 0,inplace=True)


# **Разделение сложных признаков**

# In[7]:


def fidh_shot(tims):
    first=tims.partition(",")[0]
    return first


# In[8]:


def ending(string):
    end=string.partition(",")[2]
    return end


# In[9]:


data['City']=data["Area"].apply(fidh_shot)
data['Area']=data["Area"].apply(ending)


# **Дополнение недостающими данными**

# *Создадим новый атрибут, где будет содержаться информация о категории ресторана.*

# In[10]:


for col in data['AverageCost']:
    if col < 340:
        data['Cost_category']="less expensive"
    if col > 340 or col<900:
        data['Cost_category']="average"
    else:
        data['Cost_category']="expensive"


# **Удаление пробелов**

# In[11]:


for column in data.columns:
    if data[column].dtype == object:
        data[column] = data[column].map(str.strip)


# In[12]:


cdf=data.copy()


# **Кодирование номинативных признаков**

# In[13]:


lbl=LabelEncoder()
non_nomic=data.select_dtypes(exclude=[np.number])
cell_col=non_nomic.columns.values
for col in cell_col:
    data[col]=lbl.fit_transform(data[col])


# **Формирование структуры набора данных**

# *Разделение данных:*

# In[14]:


X = data.drop('Dinner Ratings',axis=1)
y = data['Dinner Ratings']
X_train, X_test, y_train, y_test = train_test_split(X, y,random_state=10)


# In[15]:


data.shape


# In[16]:


rfe = RFE(estimator=LGBMClassifier(), n_features_to_select=7)


# In[17]:


model = LGBMClassifier()


# In[18]:


pipe = Pipeline([("Feature Selection", rfe), ("Model", model)])
cv = RepeatedStratifiedKFold(n_repeats=5, random_state=36851234, n_splits=2)
n_scores = cross_val_score(pipe, X_train, y_train, scoring="accuracy", cv=cv, n_jobs=-1)
np.mean(n_scores)


# In[19]:


pipe.fit(X_train, y_train)


# *Ранжирование признака:*

# In[20]:


pd.DataFrame(rfe.support_,index=X.columns,columns=["Dinner Ratings"])


# In[21]:


rf_df = pd.DataFrame(rfe.ranking_,index=X.columns,columns=["Dinner Ratings"]).sort_values(by="Dinner Ratings",ascending=True)


# In[22]:


rf_df.head()


# *Из выведенной таблицы можно сделать вывод, что для целевой переменной важны только 5 признаков и 7 имеют хорошую зависимость.Поэтому для обучения оставим только их.*

# In[23]:


data=data[['Name','Cuisines','Full_Address','PeopleKnownFor','PopularDishes','Dinner Reviews','Delivery Reviews','Dinner Ratings','AverageCost']]


# **Формирование словарей данных**

# In[24]:


def step1(x):
    for i in x:
        a=str(i).lower()
        p=re.sub(r'[^a-z0-9]',' ',a)
        print(p)


# In[25]:


def text_normalization(text):
    text=str(text).lower() 
    spl_char_text=re.sub(r'[^ a-z]','',text) 
    tokens=nltk.word_tokenize(spl_char_text) 
    lema=wordnet.WordNetLemmatizer() 
    tags_list=pos_tag(tokens,tagset=None) 
    lema_words=[]   
    for token,pos_token in tags_list:
        if pos_token.startswith('V'):  
            pos_val='v'
        elif pos_token.startswith('J'): 
            pos_val='a'
        elif pos_token.startswith('R'):
            pos_val='r'
        else:
            pos_val='n' 
        lema_token=lema.lemmatize(token,pos_val) 
        lema_words.append(lema_token) 
    
    return " ".join(lema_words)


# In[26]:


def stopword_(text):   
    tag_list=pos_tag(nltk.word_tokenize(text),tagset=None)
    stop=stopwords.words('english')
    lema=wordnet.WordNetLemmatizer()
    lema_word=[]
    for token,pos_token in tag_list:
        if token in stop:
            continue
        if pos_token.startswith('V'):
            pos_val='v'
        elif pos_token.startswith('J'):
            pos_val='a'
        elif pos_token.startswith('R'):
            pos_val='r'
        else:
            pos_val='n'
        lema_token=lema.lemmatize(token,pos_val)
        lema_word.append(lema_token)
    return " ".join(lema_word) 


# ### Кластеризация

# *Для того, что-бы приступить к обучению модели, необходимо выбрать алгоритмы для кластеризации.Наиболее подходящим алгоритмом будет являться:k-means- из-за простоты в реализации, и умении работать с большим количеством значений, PCA-он основан на уменьшении размерности выборки, TSNE-преимущества такиеже как и у анализа главных компонентов.*

# In[27]:


x=data[["Dinner Reviews","AverageCost"]]


# In[28]:


plt.figure(figsize=(4,4))
wcss=[]
for i in range(1,11):
    kmeans=KMeans(n_clusters=i, init='k-means++').fit(x)
    wcss.append(kmeans.inertia_)
plt.grid(color='black')
plt.plot(wcss, range(1,11), color='red');


# In[29]:


ch=AgglomerativeClustering(n_clusters=2, affinity='euclidean', linkage='ward')
cd_pred=ch.fit_predict(x)


# In[30]:


x=x.values


# In[31]:


plt.figure(figsize=(15,10))
plt.title('K-means')
plt.scatter(x[cd_pred==0,0], x[cd_pred==0,1], s=100, c='red', label='Severe danger')
plt.scatter(x[cd_pred==1,0], x[cd_pred==1,1], s=100, c='blue', label='Average danger')
plt.scatter(kmeans.cluster_centers_[:,0],kmeans.cluster_centers_[:,1], s=100, c='green',label='Intermediate')
plt.legend()
plt.grid()
plt.show();


# *Из представленного графика видно, что чем ниже рейтинг ужина, тем ниже цена ужина.*

# ### Классификация 

# *Теперь нужно решить, какую модель классификации будем использовать.Мне кажется, больше всего подходит алгоритм Дерева решений или k-ближайших соседей, так как выборка относительно малого размера, и также эти классификаторы не чувствительны к выбросам в данных.Еще применим ансамблевые алгоритмы, потомучто они способны давать более лучшие результаты, так как комбинируют прогнозы из двух и более алгоритмов машинного обучения.Импортируем эти классификаторы:*

# In[32]:


from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score


# *Нужно привести все признаки кроме целевого в правильный вид, для этого воспользуемся модулем библиотеки MinMaxScaler,которая нормализует выборку.*

# In[33]:


max_min=MinMaxScaler()


# In[34]:


df_scal=max_min.fit_transform(data.drop('Dinner Ratings', axis=1))


# In[35]:


pd_df_scal=pd.DataFrame(df_scal,columns=data.drop('Dinner Ratings', axis=1).columns)


# *Тренировочная часть будет состовлять-80% от всей выборки, а тестовая-20%.*

# In[36]:


X=df_scal.copy()
Y=data['Dinner Ratings']
X_train, X_test, Y_train, Y_test=train_test_split(X,Y, test_size=0.2, random_state=30)


# ### Визуализация зависимостей данных

# *Выведим на экран попарный график зависимости:*

# In[37]:


sns.pairplot(data, palette='Set1',hue='AverageCost');


# *Видно, что все признаки хаотично распределены по графику, это говорит о том , что зависимость признаков хорошая.*

# *Визуализируем целевой признак, что бы посмотреть его распределения:*

# In[38]:


sns.distplot(data['Dinner Ratings'], color='orange');


# *Видно, что целевой атрибут имеет больше симметричное распределение, так как изначально возрастают, а в конце убывают, это должно хорошо повлиять при обучении модели классификации.*

# *Теперь посмотрим коэффициент корреляции, чтобы увидеть зависимость целевой переменной от всех других:*

# In[39]:


plt.figure(figsize=(8, 12))
heatmap = sns.heatmap(data.corr()[['Dinner Ratings']].sort_values(by='Dinner Ratings', ascending=False), vmin=-1, vmax=1, annot=True, cmap='BrBG',fmt=".1f")
heatmap.set_title('Features Correlating with Sales Price', fontdict={'fontsize':18}, pad=16);


# *Удалю признаки где коэффициент корреляции больше 0.3*

# In[40]:


del data['AverageCost']


# *Как видно, целевой признак имеет мало схожести с другими атрибутами, это также хорошо повлияет на дольнейее обучение.*

# ### Обучение

# *Обучения с классификатором Дерево решений:*

# In[41]:


tree=DecisionTreeClassifier(random_state=4)


# In[42]:


tree.fit(X_train, Y_train)


# In[43]:


y_pred=tree.predict(X_test)


# In[44]:


tree.score(X_test, Y_test)


# In[45]:


accuracy_score(Y_test, y_pred)


# *Применим для обучения алгоритм k-ближайших соседей:*

# In[46]:


np.random.seed(1)
knn_clf=KNeighborsClassifier(n_neighbors=23)


# In[47]:


knn_clf.fit(X_train, Y_train)


# In[48]:


y_pred = knn_clf.predict(X_test)


# In[49]:


knn_clf.score(X_test, Y_test)


# *Обучение с помощью ансамблевого алгоритма XGBClassifier:*

# In[50]:


xgb=XGBClassifier(random_state=120,n_estmats=22, learning_rate=0.19,min_child_weight=1,gamma=0,subsample=0.9,colsample_bytree=0.8,nthread=4,scale_pos_weight=1,seed=27)


# In[51]:


xgb.fit(X_train, Y_train)


# In[52]:


y_pred=xgb.predict(X_test)


# In[53]:


xgb.score(X_test, Y_test)


# *Обучения при помощи алгоритм AdaBoost:*

# In[54]:


ada=AdaBoostClassifier(random_state=120, n_estimators=20, learning_rate=0.19)


# In[55]:


ada.fit(X_train, Y_train)


# In[56]:


y_pred=ada.predict(X_test)


# In[57]:


ada.score(X_test, Y_test)


# *Ансамблевый алгоритм LGBMClassifier:*

# In[58]:


lgbm = LGBMClassifier(n_estimators=14,random_state=100,learning_rate=0.19 ,max_depth=5, colsample_bytree=0.82,scale_pos_weight=1,seed=11)


# In[59]:


lgbm.fit(X_train, Y_train)


# In[60]:


y_pred= lgbm.predict(X_test)


# In[61]:


lgbm.score(X_test ,Y_test)


# *Лучшим алгоритмом оказался XGBClassifier, он обучил модель с точность 65%*

# ### Чат-бот

# *Обучения бота искать стоимость рестарана по названию*

# In[100]:


cdf_1=cdf[['Name','City']]


# In[101]:


step1(cdf_1['Name'])


# In[102]:


cdf_1['lemmatized_text_1']=cdf_1['Name'].apply(text_normalization)


# In[103]:


cv = CountVectorizer() 
X = cv.fit_transform(cdf_1['lemmatized_text_1']).toarray()


# In[104]:


features = cv.get_feature_names()
df_bow = pd.DataFrame(X, columns = features)
df_bow.head()


# In[105]:


def chat_bow_1(text):
    s=stopword_(text)
    lemma=text_normalization(s) 
    bow=cv.transform([lemma]).toarray() 
    cosine_value = 1- pairwise_distances(df_bow,bow, metric = 'cosine' )
    index_value=cosine_value.argmax() 
    return cdf_1['City'].loc[index_value]


# *Обучения бота искать отзыв доставки по названию*

# In[106]:


cdf_2=cdf[['Name','Delivery Ratings']]


# In[107]:


step1(cdf_2['Name'])


# In[108]:


cdf_2['lemmatized_text_2']=cdf_2['Name'].apply(text_normalization)


# In[109]:


cv = CountVectorizer() 
X = cv.fit_transform(cdf_2['lemmatized_text_2']).toarray()


# In[110]:


features = cv.get_feature_names()
df_bow = pd.DataFrame(X, columns = features)
df_bow.head()


# In[111]:


def chat_bow_2(text):
    s=stopword_(text)
    lemma=text_normalization(s) 
    bow=cv.transform([lemma]).toarray() 
    cosine_value = 1- pairwise_distances(df_bow,bow, metric = 'cosine' )
    index_value=cosine_value.argmax() 
    return cdf_2['Delivery Ratings'].loc[index_value]


# In[112]:


continue_dialogue = True
print("Bot: Введите команду /comand, что-бы посмотреть,\nкакие команды я умею выполнять.")
while(continue_dialogue == True):
    human_text = input()
    human_text = human_text.lower()
    if human_text != '/end':
        if human_text == '/comand':
            print("Bot: Я умею выполнять следующие команды: \n/comand, /predict, /severity, /end.")
        elif human_text == '/predict':
            pred=input('Введите название ресторана, что бы посмотреть отзыв доставки:')
            print("Отзыв доставки-" + chat_bow_2(pred))
        elif human_text == '/severity':
            intent=input('Введите название ресторана, что бы посмотреть в какои городе он находится:')
            print("Bot:Город, где находится ресторан-" + chat_bow_1(intent))
        else:
            print('Bot: Такие команды я не умею выполнять, введите /comand,что-бы посмотреть,\nкакие команды я умею выполнять.')
    else:
        continue_dialogue = False
        print("Bot: Пока")


# ### API

# In[113]:


from flask import render_template, request, jsonify
import flask
import numpy as np
import traceback
import pickle
import pandas as pd


# In[114]:


import pickle
with open('model.pkl','wb') as file:
    pickle.dump(xgb, file)


# In[115]:


model_columns = list(X)
with open('model_columns.pkl','wb') as file:
    pickle.dump(model_columns, file)


# In[ ]:


from flask import render_template, request, jsonify
import flask
import numpy as np
import traceback
import pickle
import pandas as pd
from flask import Flask

app = Flask(__name__,template_folder='templates')
 
# importing models
with open('model.pkl', 'rb') as f:
    xgb = pickle.load (f)

with open('model_columns.pkl', 'rb') as f:
    model_columns = pickle.load (f)
@app.route('/predict', methods=['POST','GET'])
def predict():
   if flask.request.method == 'POST':
        try:
            json_ = request.json
            print(json_)
            query_ = pd.get_dummies(pd.DataFrame(json_))
            query = query_.reindex(columns = model_columns, fill_value= 0)
            prediction = list(xgb.predict(query))
 
            return jsonify({
                "prediction":str(prediction)
            })
 
        except:
            return jsonify({
                "trace": traceback.format_exc()
            })
      
 
if __name__ == "__main__":
   app.run()


# In[ ]:




